#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite[] cacheBadBuddha_IB_FibExtensions_Lite;

		
		public BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite BadBuddha_IB_FibExtensions_Lite(bool enableUpdateChecks, int iBLengthMinutes, int startOffsetMinutesFromSessionOpen, bool useFixedIBStartTime, string iBStartTime, bool anchorToCalendarDay, bool showIBRectangle, bool showMidline, bool extendToSessionEnd, bool showLabels, int lineWidth, Color iBColor, Color midlineColor, Color extUpColor, Color extDownColor, Color rectFillColor, int rectFillOpacityPct)
		{
			return BadBuddha_IB_FibExtensions_Lite(Input, enableUpdateChecks, iBLengthMinutes, startOffsetMinutesFromSessionOpen, useFixedIBStartTime, iBStartTime, anchorToCalendarDay, showIBRectangle, showMidline, extendToSessionEnd, showLabels, lineWidth, iBColor, midlineColor, extUpColor, extDownColor, rectFillColor, rectFillOpacityPct);
		}


		
		public BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite BadBuddha_IB_FibExtensions_Lite(ISeries<double> input, bool enableUpdateChecks, int iBLengthMinutes, int startOffsetMinutesFromSessionOpen, bool useFixedIBStartTime, string iBStartTime, bool anchorToCalendarDay, bool showIBRectangle, bool showMidline, bool extendToSessionEnd, bool showLabels, int lineWidth, Color iBColor, Color midlineColor, Color extUpColor, Color extDownColor, Color rectFillColor, int rectFillOpacityPct)
		{
			if (cacheBadBuddha_IB_FibExtensions_Lite != null)
				for (int idx = 0; idx < cacheBadBuddha_IB_FibExtensions_Lite.Length; idx++)
					if (cacheBadBuddha_IB_FibExtensions_Lite[idx].EnableUpdateChecks == enableUpdateChecks && cacheBadBuddha_IB_FibExtensions_Lite[idx].IBLengthMinutes == iBLengthMinutes && cacheBadBuddha_IB_FibExtensions_Lite[idx].StartOffsetMinutesFromSessionOpen == startOffsetMinutesFromSessionOpen && cacheBadBuddha_IB_FibExtensions_Lite[idx].UseFixedIBStartTime == useFixedIBStartTime && cacheBadBuddha_IB_FibExtensions_Lite[idx].IBStartTime == iBStartTime && cacheBadBuddha_IB_FibExtensions_Lite[idx].AnchorToCalendarDay == anchorToCalendarDay && cacheBadBuddha_IB_FibExtensions_Lite[idx].ShowIBRectangle == showIBRectangle && cacheBadBuddha_IB_FibExtensions_Lite[idx].ShowMidline == showMidline && cacheBadBuddha_IB_FibExtensions_Lite[idx].ExtendToSessionEnd == extendToSessionEnd && cacheBadBuddha_IB_FibExtensions_Lite[idx].ShowLabels == showLabels && cacheBadBuddha_IB_FibExtensions_Lite[idx].LineWidth == lineWidth && cacheBadBuddha_IB_FibExtensions_Lite[idx].IBColor == iBColor && cacheBadBuddha_IB_FibExtensions_Lite[idx].MidlineColor == midlineColor && cacheBadBuddha_IB_FibExtensions_Lite[idx].ExtUpColor == extUpColor && cacheBadBuddha_IB_FibExtensions_Lite[idx].ExtDownColor == extDownColor && cacheBadBuddha_IB_FibExtensions_Lite[idx].RectFillColor == rectFillColor && cacheBadBuddha_IB_FibExtensions_Lite[idx].RectFillOpacityPct == rectFillOpacityPct && cacheBadBuddha_IB_FibExtensions_Lite[idx].EqualsInput(input))
						return cacheBadBuddha_IB_FibExtensions_Lite[idx];
			return CacheIndicator<BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite>(new BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite(){ EnableUpdateChecks = enableUpdateChecks, IBLengthMinutes = iBLengthMinutes, StartOffsetMinutesFromSessionOpen = startOffsetMinutesFromSessionOpen, UseFixedIBStartTime = useFixedIBStartTime, IBStartTime = iBStartTime, AnchorToCalendarDay = anchorToCalendarDay, ShowIBRectangle = showIBRectangle, ShowMidline = showMidline, ExtendToSessionEnd = extendToSessionEnd, ShowLabels = showLabels, LineWidth = lineWidth, IBColor = iBColor, MidlineColor = midlineColor, ExtUpColor = extUpColor, ExtDownColor = extDownColor, RectFillColor = rectFillColor, RectFillOpacityPct = rectFillOpacityPct }, input, ref cacheBadBuddha_IB_FibExtensions_Lite);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite BadBuddha_IB_FibExtensions_Lite(bool enableUpdateChecks, int iBLengthMinutes, int startOffsetMinutesFromSessionOpen, bool useFixedIBStartTime, string iBStartTime, bool anchorToCalendarDay, bool showIBRectangle, bool showMidline, bool extendToSessionEnd, bool showLabels, int lineWidth, Color iBColor, Color midlineColor, Color extUpColor, Color extDownColor, Color rectFillColor, int rectFillOpacityPct)
		{
			return indicator.BadBuddha_IB_FibExtensions_Lite(Input, enableUpdateChecks, iBLengthMinutes, startOffsetMinutesFromSessionOpen, useFixedIBStartTime, iBStartTime, anchorToCalendarDay, showIBRectangle, showMidline, extendToSessionEnd, showLabels, lineWidth, iBColor, midlineColor, extUpColor, extDownColor, rectFillColor, rectFillOpacityPct);
		}


		
		public Indicators.BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite BadBuddha_IB_FibExtensions_Lite(ISeries<double> input , bool enableUpdateChecks, int iBLengthMinutes, int startOffsetMinutesFromSessionOpen, bool useFixedIBStartTime, string iBStartTime, bool anchorToCalendarDay, bool showIBRectangle, bool showMidline, bool extendToSessionEnd, bool showLabels, int lineWidth, Color iBColor, Color midlineColor, Color extUpColor, Color extDownColor, Color rectFillColor, int rectFillOpacityPct)
		{
			return indicator.BadBuddha_IB_FibExtensions_Lite(input, enableUpdateChecks, iBLengthMinutes, startOffsetMinutesFromSessionOpen, useFixedIBStartTime, iBStartTime, anchorToCalendarDay, showIBRectangle, showMidline, extendToSessionEnd, showLabels, lineWidth, iBColor, midlineColor, extUpColor, extDownColor, rectFillColor, rectFillOpacityPct);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite BadBuddha_IB_FibExtensions_Lite(bool enableUpdateChecks, int iBLengthMinutes, int startOffsetMinutesFromSessionOpen, bool useFixedIBStartTime, string iBStartTime, bool anchorToCalendarDay, bool showIBRectangle, bool showMidline, bool extendToSessionEnd, bool showLabels, int lineWidth, Color iBColor, Color midlineColor, Color extUpColor, Color extDownColor, Color rectFillColor, int rectFillOpacityPct)
		{
			return indicator.BadBuddha_IB_FibExtensions_Lite(Input, enableUpdateChecks, iBLengthMinutes, startOffsetMinutesFromSessionOpen, useFixedIBStartTime, iBStartTime, anchorToCalendarDay, showIBRectangle, showMidline, extendToSessionEnd, showLabels, lineWidth, iBColor, midlineColor, extUpColor, extDownColor, rectFillColor, rectFillOpacityPct);
		}


		
		public Indicators.BadBuddhaCustoms.BadBuddha_IB_FibExtensions_Lite BadBuddha_IB_FibExtensions_Lite(ISeries<double> input , bool enableUpdateChecks, int iBLengthMinutes, int startOffsetMinutesFromSessionOpen, bool useFixedIBStartTime, string iBStartTime, bool anchorToCalendarDay, bool showIBRectangle, bool showMidline, bool extendToSessionEnd, bool showLabels, int lineWidth, Color iBColor, Color midlineColor, Color extUpColor, Color extDownColor, Color rectFillColor, int rectFillOpacityPct)
		{
			return indicator.BadBuddha_IB_FibExtensions_Lite(input, enableUpdateChecks, iBLengthMinutes, startOffsetMinutesFromSessionOpen, useFixedIBStartTime, iBStartTime, anchorToCalendarDay, showIBRectangle, showMidline, extendToSessionEnd, showLabels, lineWidth, iBColor, midlineColor, extUpColor, extDownColor, rectFillColor, rectFillOpacityPct);
		}

	}
}

#endregion
